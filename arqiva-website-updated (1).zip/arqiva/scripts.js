/*
 * ARQIVA scripts.js — Enhanced & Bug-fixed
 *
 * Features:
 *  1. Header compact on scroll
 *  2. Scroll reveal (IntersectionObserver)
 *  3. Mobile hamburger menu (accessible)
 *  4. Active nav link highlighting
 *  5. Keyboard: Escape closes mobile menu
 *  6. Close mobile menu when nav link clicked
 */

(() => {
  'use strict';

  // ── 1. Header compact on scroll ──────────────────────────
  const header = document.getElementById('site-header');

  function updateHeader() {
    header.classList.toggle('scrolled', window.scrollY > 50);
  }

  updateHeader(); // run on load
  window.addEventListener('scroll', updateHeader, { passive: true });


  // ── 2. Scroll reveal ─────────────────────────────────────
  const revealEls = document.querySelectorAll('.reveal');

  if ('IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          revealObserver.unobserve(entry.target); // fire once
        }
      });
    }, {
      threshold: 0.08,
      rootMargin: '0px 0px -40px 0px'
    });

    revealEls.forEach(el => revealObserver.observe(el));
  } else {
    // Fallback: just show everything immediately
    revealEls.forEach(el => el.classList.add('visible'));
  }


  // ── 3. Mobile hamburger menu ──────────────────────────────
  const menuBtn    = document.getElementById('menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileLinks = document.querySelectorAll('.mobile-link');

  function openMenu() {
    menuBtn.classList.add('open');
    mobileMenu.classList.add('open');
    menuBtn.setAttribute('aria-expanded', 'true');
    mobileMenu.setAttribute('aria-hidden', 'false');
  }

  function closeMenu() {
    menuBtn.classList.remove('open');
    mobileMenu.classList.remove('open');
    menuBtn.setAttribute('aria-expanded', 'false');
    mobileMenu.setAttribute('aria-hidden', 'true');
  }

  function toggleMenu() {
    if (mobileMenu.classList.contains('open')) {
      closeMenu();
    } else {
      openMenu();
    }
  }

  if (menuBtn) {
    menuBtn.addEventListener('click', toggleMenu);
  }

  // Close menu when any mobile link is clicked
  mobileLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  // Close menu on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && mobileMenu.classList.contains('open')) {
      closeMenu();
      menuBtn.focus();
    }
  });

  // Close menu if user resizes to desktop width
  window.addEventListener('resize', () => {
    if (window.innerWidth > 1100) {
      closeMenu();
    }
  }, { passive: true });


  // ── 4. Active nav link highlighting ──────────────────────
  const sections  = document.querySelectorAll('section[id], div[id]');
  const navLinks  = document.querySelectorAll('.nav-link');

  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          const isActive = link.getAttribute('href') === `#${id}`;
          link.style.color = isActive ? 'var(--ink)' : '';
        });
      }
    });
  }, {
    threshold: 0.4
  });

  sections.forEach(section => sectionObserver.observe(section));


  // ── 5. Smooth scroll offset for fixed header ─────────────
  // Ensures anchor links land below the fixed header
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', (e) => {
      const href = anchor.getAttribute('href');
      if (href === '#') return;

      const target = document.querySelector(href);
      if (!target) return;

      e.preventDefault();

      const headerHeight = header.offsetHeight;
      const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 16;

      window.scrollTo({ top, behavior: 'smooth' });
    });
  });

})();
